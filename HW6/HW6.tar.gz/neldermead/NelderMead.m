
%this is the 2-d implementation
%x1,x2,x3 are initial guess, and f is the function handle
function min = NelderMead(x1,x2,x3, f)
%hard coded parameter values
rho =1;
chi =2;
gamma = 0.5;
sigma = 0.5;







end