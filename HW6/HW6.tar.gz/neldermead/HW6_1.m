
%HW6_1

%this program will be the shell for core minimization function,
%then this .m will be able to scan through space and find minima
